# eurosat
Train standard Convolutional Neural Network to predict land cover type from multispectral Sentinel-2 satellite imagery
https://nbviewer.jupyter.org/github/chris010970/eurosat/blob/master/notebooks/predict.ipynb
