# eurosat
Download dataset and papers from here: https://github.com/phelber/eurosat